<?php

namespace App\Http\Resources;

use App\Models\Transaction;
use Illuminate\Http\Resources\Json\JsonResource;

class TransactionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'total_price' => $this->total_price,
            'unique_number' => $this->unique_number,
            'discount' => $this->discount,
            'coupon' => $this->coupon,
            'description' => $this->description,
            'bank' => $this->bank,
            'invoice_id' => $this->invoice_id,
            'status' => $this->status,
            'eod_id' => $this->eod_id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'transaction_detail' => new TransactionDetailCollection(TransactionResource::collection($this->transaction_detail))
        ];
    }
}
