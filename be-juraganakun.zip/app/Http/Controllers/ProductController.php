<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $isSuccess = true;
        $data = null;
        $msg = "Berhasil membuat product ".$request->name;

        try{
            $data = Product::create([
                'product_code' => $request->product_code,
                'product_name' => $request->product_name,
                'cogs' => $request->cogs,
                'price' => $request->price,
                'description' => $request->description,
                'distributor' => $request->distributor,
                'category_id' => $request->category_id,
                'user_create' => Auth::id()
            ]);

        }catch(Exception $e){
            $msg = $e->getMessage();
            $isSuccess = false;
        }
        
        return response()->json([
            'data' => $data,
            'isSuccess' => $isSuccess,
            'msg' => $msg
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $isSuccess = true;
        $msg = 'Produk berhasil diupdate';
        $data = Product::find($request->id);
        if(! $data){
            return response()->json([
                'isSuccess' => false,
                'msg' => 'Produk tidak ditemukan!',
                'data' => 'ID '.$request->id.' NOT FOUND'
            ]);
        }

        $data->product_code = $request->product_code == null ? $data->product_code : $request->product_code ;
        $data->product_name = $request->product_name == null ? $data->product_name : $request->product_name ;
        $data->cogs = $request->cogs == null ? $data->cogs : $request->cogs ;
        $data->price = $request->price == null ? $data->price : $request->price ;
        $data->description = $request->description == null ? $data->description : $request->description ;
        $data->distributor = $request->distributor == null ? $data->distributor : $request->distributor ;
        $data->category_id = $request->category_id == null ? $data->category_id : $request->category_id ;
        $data->user_update = Auth::id();
        $data->save();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $isSuccess = true;
        $msg = 'Produk berhasil dihapus';
        $data = Product::find($request->id);
        if(! $data){
            return response()->json([
                'isSuccess' => false,
                'msg' => 'Produk tidak ditemukan!',
                'data' => 'ID '.$request->id.' NOT FOUND'
            ]);
        }
        $data->name = $request->name;
        $data->delete();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }
    
    public function getAll()
    {
        $isSuccess = true;
        $msg = 'SUCCESS';
        $data = Product::all();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    public function get()
    {
        $isSuccess = true;
        $msg = 'SUCCESS';
        $data = Product::where('status',1)->get();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    public function setActive(Request $request)
    {
        $isSuccess = true;
        $msg = 'Produk berhasil diaktifkan';
        $data = Product::find($request->id);
        if(! $data){
            return response()->json([
                'isSuccess' => false,
                'msg' => 'Produk tidak ditemukan!',
                'data' => 'ID '.$request->id.' NOT FOUND'
            ]);
        }
        $data->status = 1;
        $data->save();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    public function setDisable(Request $request)
    {
        $isSuccess = true;
        $msg = 'Produk berhasil dinonaktifkan';
        $data = Product::find($request->id);
        if(! $data){
            return response()->json([
                'isSuccess' => false,
                'msg' => 'Produk tidak ditemukan!',
                'data' => 'ID '.$request->id.' NOT FOUND'
            ]);
        }
        $data->status = 9;
        $data->save();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }
}
