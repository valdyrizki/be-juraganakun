<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $isSuccess = true;
        $data = null;
        $msg = "Berhasil membuat kategori ".$request->name;

        try{
            $data = Category::create([
                'name' => $request->name,
                'user_create' => Auth::id()
            ]);

        }catch(Exception $e){
            $msg = $e->getMessage();
            $isSuccess = false;
        }
        
        return response()->json([
            'data' => $data,
            'isSuccess' => $isSuccess,
            'msg' => $msg
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $isSuccess = true;
        $msg = 'Kategori berhasil diupdate';
        $data = Category::find($request->id);
        if(! $data){
            return response()->json([
                'isSuccess' => false,
                'msg' => 'Kategori tidak ditemukan!',
                'data' => 'ID '.$request->id.' NOT FOUND'
            ]);
        }
        $data->name = $request->name;
        $data->user_update = Auth::id();
        $data->save();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $isSuccess = true;
        $msg = 'Kategori berhasil dihapus';
        $data = Category::find($request->id);
        if(! $data){
            return response()->json([
                'isSuccess' => false,
                'msg' => 'Kategori tidak ditemukan!',
                'data' => 'ID '.$request->id.' NOT FOUND'
            ]);
        }
        $data->name = $request->name;
        $data->delete();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }
    
    public function getAll()
    {
        $isSuccess = true;
        $msg = 'SUCCESS';
        $data = Category::all();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    public function get()
    {
        $isSuccess = true;
        $msg = 'SUCCESS';
        $data = Category::where('status',1)->get();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    public function setActive(Request $request)
    {
        $isSuccess = true;
        $msg = 'Kategori berhasil diaktifkan';
        $data = Category::find($request->id);
        if(! $data){
            return response()->json([
                'isSuccess' => false,
                'msg' => 'Kategori tidak ditemukan!',
                'data' => 'ID '.$request->id.' NOT FOUND'
            ]);
        }
        $data->status = 1;
        $data->save();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }

    public function setDisable(Request $request)
    {
        $isSuccess = true;
        $msg = 'Kategori berhasil dinonaktifkan';
        $data = Category::find($request->id);
        if(! $data){
            return response()->json([
                'isSuccess' => false,
                'msg' => 'Kategori tidak ditemukan!',
                'data' => 'ID '.$request->id.' NOT FOUND'
            ]);
        }
        $data->status = 9;
        $data->save();

        return response()->json([
            'isSuccess' => $isSuccess,
            'msg' => $msg,
            'data' => $data,
        ]);
    }
}
