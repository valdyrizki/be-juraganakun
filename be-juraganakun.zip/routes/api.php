<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\UserController;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/test', function () {
        return 'Hello World';
    });

    Route::controller(UserController::class)->group((function() {
        Route::post('/user/store','store');
        Route::get('/user/getall','getAll');
        Route::get('/user/get','get');
        Route::get('/user/getbyid','getById');
        Route::PUT('/user/update','update');
        Route::PUT('/user/setactive','setActive');
        Route::PUT('/user/setdisable','setDisable');
        Route::DELETE('/user/destroy','destroy');
    }));

    Route::controller(ProductController::class)->group((function() {
        Route::post('/product/store','store');
        Route::get('/product/getall','getAll');
        Route::get('/product/get','get');
        Route::PUT('/product/update','update');
        Route::PUT('/product/setactive','setActive');
        Route::PUT('/product/setdisable','setDisable');
        Route::DELETE('/product/destroy','destroy');
    }));

    Route::controller(CategoryController::class)->group((function() {
        Route::post('/category/store','store');
        Route::get('/category/getall','getAll');
        Route::get('/category/get','get');
        Route::PUT('/category/update','update');
        Route::PUT('/category/setactive','setActive');
        Route::PUT('/category/setdisable','setDisable');
        Route::DELETE('/category/destroy','destroy');
    }));

    Route::controller(TransactionController::class)->group((function() {
        Route::post('/transaction/store','store');
        Route::get('/transaction/get','get');
        Route::get('/transaction/getbyinvoice','getByInvoice');
        Route::get('/transaction/getactive','getActive'); //Belum dibayar
        Route::get('/transaction/getdone','getDone'); //Sudah dibayar
        Route::get('/transaction/getcancel','getCancel'); 
        Route::get('/transaction/getrefund','getRefund');
        Route::get('/transaction/getexpired','getExpired');
        // Route::PUT('/transaction/update','update');
        Route::PUT('/transaction/setactive','setActive');
        Route::PUT('/transaction/setdone','setDone');
        Route::PUT('/transaction/setcancel','setCancel');
        Route::PUT('/transaction/setrefund','setRefund');
        Route::PUT('/transaction/setexpired','setExpired');
    }));
});

Route::controller(AuthController::class)->group((function() {
    Route::post('/auth/register','register');
    Route::post('/auth/login','login');
}));
